int main(){
while(1);
}

int main(){
while(1);
}

int main(){
while(1);
}

int main(){
while(1);
}

int main(){
while(1);
}

int main(){
while(1);
}
